Amar LMS - Offline Android TV App (Java + ExoPlayer)
-------------------------------------------------------------
- 100% offline playback from /sdcard/AmarLMS/<Subject>/<Topic>/<video>.mp4
- Android TV ready (LEANBACK_LAUNCHER)
- Entry activity: com.amar.lms.MainActivity
Build steps:
1) Open this folder in Android Studio.
2) Let Gradle sync; if prompted, upgrade Gradle plugin.
3) Build > Build APK(s). Install on Android TV.
